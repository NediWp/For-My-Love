# For My Love — G + N

A 10-day love-note site for Giovanni.

## Current setup
- Day 1 begins on August 24, 2026.
- The same link can be used every day.
- Future days are locked automatically.
- Previous/current unlocked days can be opened.
- The opening page, 10-day grid, modal cards, responsive styling, and all 10 final notes are included.
- No database is required for the date-based unlocking.

## Publishing
This can be published with GitHub Pages, Netlify, or another static hosting service.
